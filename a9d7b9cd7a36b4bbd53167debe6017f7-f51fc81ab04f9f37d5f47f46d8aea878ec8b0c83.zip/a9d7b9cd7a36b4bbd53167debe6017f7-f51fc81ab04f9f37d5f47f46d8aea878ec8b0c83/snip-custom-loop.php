<?php
/*
Plugin Name: SNIP Custom Loop
Version: 0.1.0
Description: Example that shows how to create custom loops.
*/

add_filter( 'wpbuddy/rich_snippets/fields/loop_subselect/values', 'csnip_loop_values', 10, 1 );

/**
 * Adds a custom value to the loop select box.
 *
 * @param array $values
 *
 * @return array
 */
function csnip_loop_values( $values ) {

	$values['csnip_custom_loop'] = __( 'Custom Loop', 'csnip-loops' );

	return $values;
}

add_filter( 'wpbuddy/rich_snippets/rich_snippet/loop/items', 'csnip_loop_items', 10, 3 );


/**
 * The items to choose.
 *
 * @param array                               $items
 * @param \wpbuddy\rich_snippets\Rich_Snippet $snippet
 * @param int                                 $post_id
 *
 * @return array
 */
function csnip_loop_items( $items, $snippet, $post_id ) {

	if ( 'csnip_custom_loop' !== $snippet->get_loop_type() ) {
		return $items;
	}

	/**
	 * Do your custom code here.
	 * Make sure that the key is the ITEM ID.
	 */
	$my_items = [
		'item_id_1' => new stdClass(),
		'item_id_2' => new stdClass(),
	];

	return $my_items;
}